package io.github.giridhargg.graphqlclienttest.graphqlmvcconfig;

import graphql.GraphQLException;
import io.github.giridhargg.graphqlclienttest.graphqlengine.GraphQlStaticTestAssets;
import io.github.giridhargg.graphqlclienttest.graphqlengine.GraphQlStaticTestAssetsProperties;
import org.jspecify.annotations.NonNull;
import org.springframework.graphql.server.WebGraphQlInterceptor;
import org.springframework.graphql.server.WebGraphQlRequest;
import org.springframework.graphql.server.WebGraphQlResponse;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

public class PersistedQueryTestInterceptor implements WebGraphQlInterceptor {

    private static final String SHA256_HASH = "sha256Hash";

    private final Map<String, String> persistedQueries;

    public PersistedQueryTestInterceptor(GraphQlStaticTestAssetsProperties properties) {
        // even though this interceptor is being invoked for multiple requests, the persisted queries are static assets
        // that are loaded once at first test startup time and cached in memory for fast lookup on subsequent requests
        this.persistedQueries = GraphQlStaticTestAssets.forPaths(properties).persistedQueries();
    }

    @Override
    public @NonNull Mono<WebGraphQlResponse> intercept(@NonNull WebGraphQlRequest request, @NonNull Chain chain) {
        Map<String, Object> extensions = request.getExtensions();
        Map<String, Object> persisted = extensions != null
                ? (Map<String, Object>) extensions.get("persistedQuery") : null;

        if (persisted != null && persisted.get(SHA256_HASH) != null) {
            return handlePersistedQuery(request, chain, persisted);
        }
        return chain.next(request);
    }

    private Mono<WebGraphQlResponse> handlePersistedQuery(
            WebGraphQlRequest request, Chain chain, Map<String, Object> persisted) {
        var hash = (String) persisted.get(SHA256_HASH);
        var persistedQuery = persistedQueries.get(hash);
        if (persistedQuery == null) {
            return Mono.error(new GraphQLException("Persisted query not found for hash: " + hash));
        }
        Map<String, Object> body = new HashMap<>();
        body.put("query", persistedQuery);
        body.put("operationName", request.getOperationName());
        body.put("variables", request.getVariables());
        body.put("extensions", request.getExtensions());
        var newRequest = new WebGraphQlRequest(
                request.getUri().toUri(), request.getHeaders(), request.getCookies(),
                request.getRemoteAddress(), request.getAttributes(),
                body, request.getId(), request.getLocale());
        return chain.next(newRequest);
    }
}
