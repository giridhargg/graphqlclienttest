package io.github.giridhargg.graphqlclienttest.graphqlengine;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

@ConfigurationProperties("graphql.test.assets")
public record GraphQlStaticTestAssetsProperties(
        @DefaultValue("classpath:schema.graphqls")
        String schemaLocation,
        @DefaultValue("classpath:persisted-query-hashes.properties,classpath:persisted-query-hashes.yml,classpath:persisted-query-hashes.yaml")
        String persistedQueryHashesLocation,
        @DefaultValue("classpath*:persisted-queries/*.gql")
        String persistedQueriesPattern) {}
