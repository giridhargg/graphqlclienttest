package io.github.giridhargg.graphqlclienttest.graphqlmvcconfig;

import io.github.giridhargg.graphqlclienttest.shared.MockGraphQlServerResetExtension;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.context.annotation.Import;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@Import(RuntimeWiringTestAutoConfiguration.class)
@ExtendWith(MockGraphQlServerResetExtension.class)
public @interface EnableGraphQlServerTestConfiguration {
}
