package io.github.giridhargg.graphqlclienttest.mockmanager;

import graphql.ExecutionInput;
import io.github.giridhargg.graphqlclienttest.mockmanager.resolvingstrategy.typesafenestedbuilders.GraphNode;
import io.github.giridhargg.graphqlclienttest.mockmanager.resolvingstrategy.perfieldresolvers.PerFieldResolverRegistry;
import org.jspecify.annotations.Nullable;

public sealed interface ExecutionRecord {

    @Nullable ExecutionInput executionInput();
    @Nullable MatchType matchType();

    enum MatchType { EXACT, PARTIAL }

    record DeepPathBased(
            @Nullable ExecutionInput executionInput,
            GraphNode graphNode,
            @Nullable MatchType matchType) implements ExecutionRecord {
        public static DeepPathBased of(GraphNode graphNode) {
            return new DeepPathBased(null, graphNode, null);
        }
    }

    record PerFieldResolverBased(
            @Nullable ExecutionInput executionInput,
            PerFieldResolverRegistry registry,
            @Nullable MatchType matchType) implements ExecutionRecord {
        public static PerFieldResolverBased of(PerFieldResolverRegistry registry) {
            return new PerFieldResolverBased(null, registry, null);
        }
    }
}