package io.github.giridhargg.graphqlclienttest.httpgraphqlclient;

import io.github.giridhargg.graphqlclienttest.graphqlengine.GraphQlStaticTestAssets;
import io.github.giridhargg.graphqlclienttest.graphqlengine.GraphQlStaticTestAssetsProperties;
import io.github.giridhargg.graphqlclienttest.graphqlengine.GraphQlTestExecutor;
import io.github.giridhargg.graphqlclienttest.mockmanager.MockGraphQlServer;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.graphql.client.HttpGraphQlClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.reactive.function.client.WebClient;
import tools.jackson.databind.ObjectMapper;

@TestConfiguration
@Import(ObjectMapper.class)
@TestPropertySource(locations = "classpath:graphql-client-test.properties")
@EnableConfigurationProperties(GraphQlStaticTestAssetsProperties.class)
public class HttpGraphQlClientTestAutoConfiguration {

    public static final String WEB_CLIENT_TEST_BUILDER = "webClientTestBuilder";
    public static final String WEB_TEST_CLIENT = "webTestClient";
    public static final String HTTP_GRAPHQL_TEST_CLIENT = "httpGraphQlTestClient";
    public static final String GRAPHQL_STATIC_TEST_ASSETS = "graphQlStaticTestAssets";
    public static final String GRAPHQL_TEST_EXECUTOR = "graphQlTestExecutor";
    public static final String MOCK_GRAPHQL_SERVER = "mockGraphQlServer";

    @Primary
    @Bean(name = WEB_CLIENT_TEST_BUILDER)
    WebClient.Builder webClientTestBuilder() {
        return WebClient.builder()
                .baseUrl("https://spring.io/graphql")
                .defaultHeader(HttpHeaders.ACCEPT, MediaType.TEXT_EVENT_STREAM_VALUE);
    }

    @Primary
    @Bean(GRAPHQL_STATIC_TEST_ASSETS)
    GraphQlStaticTestAssets.Assets assets(GraphQlStaticTestAssetsProperties properties) {
        return GraphQlStaticTestAssets.forPaths(properties);
    }

    @Primary
    @Bean(GRAPHQL_TEST_EXECUTOR)
    @DependsOn(GRAPHQL_STATIC_TEST_ASSETS)
    GraphQlTestExecutor graphQlTestExecutor(
            ObjectProvider<MockGraphQlServer> mockGraphQlServerProvider,
            @Qualifier(GRAPHQL_STATIC_TEST_ASSETS)
            GraphQlStaticTestAssets.Assets grapQlAssets) {
        return new GraphQlTestExecutor(mockGraphQlServerProvider, grapQlAssets);
    }

    @Primary
    @Bean(MOCK_GRAPHQL_SERVER)
    @DependsOn({WEB_CLIENT_TEST_BUILDER, GRAPHQL_TEST_EXECUTOR})
    MockGraphQlServer mockGraphQlServiceServer(
            @Qualifier(WEB_CLIENT_TEST_BUILDER)
            WebClient.Builder webClientBuilder,
            @Qualifier(GRAPHQL_TEST_EXECUTOR)
            GraphQlTestExecutor graphQlTestExecutor,
            ObjectMapper objectMapper) {
        return InMemoryMockGraphQlServer.createServer(webClientBuilder, graphQlTestExecutor, objectMapper);
    }

    @Primary
    @Bean(WEB_TEST_CLIENT)
    @DependsOn(MOCK_GRAPHQL_SERVER)
    WebClient webTestClient(@Qualifier(WEB_CLIENT_TEST_BUILDER) WebClient.Builder builder) {
        return builder.build();
    }

    @Primary
    @Bean(HTTP_GRAPHQL_TEST_CLIENT)
    @DependsOn(WEB_TEST_CLIENT)
    HttpGraphQlClient httpGraphQlTestClient(@Qualifier(WEB_TEST_CLIENT) WebClient webClient) {
        return HttpGraphQlClient.builder(webClient).build();
    }
}
