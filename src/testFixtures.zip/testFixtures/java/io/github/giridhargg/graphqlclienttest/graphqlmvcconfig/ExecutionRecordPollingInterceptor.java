package io.github.giridhargg.graphqlclienttest.graphqlmvcconfig;

import graphql.ExecutionResult;
import io.github.giridhargg.graphqlclienttest.mockmanager.MockGraphQlServer;
import org.jspecify.annotations.NonNull;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.graphql.server.WebGraphQlInterceptor;
import org.springframework.graphql.server.WebGraphQlRequest;
import org.springframework.graphql.server.WebGraphQlResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class ExecutionRecordPollingInterceptor implements WebGraphQlInterceptor {

    private final ObjectProvider<MockGraphQlServer> mockGraphQlServerObjectProvider;

    public ExecutionRecordPollingInterceptor(ObjectProvider<MockGraphQlServer> mockGraphQlServerObjectProvider) {
        this.mockGraphQlServerObjectProvider = mockGraphQlServerObjectProvider;
    }

//    @Override
//    public @NonNull Mono<WebGraphQlResponse> intercept(@NonNull WebGraphQlRequest request, @NonNull Chain chain) {
//        var a = 10;
//        var b = 30;
//        return chain.next(request)
//                .doOnNext(res -> {
//                    mockGraphQlServerObjectProvider.getObject().getExpectationManager().pollExecutionRecord();
//                })
//                .doOnError(_ -> {
//                    mockGraphQlServerObjectProvider.getObject().getExpectationManager().pollExecutionRecord();
//                });
//    }

    @Override
    public @NonNull Mono<WebGraphQlResponse> intercept(
            @NonNull WebGraphQlRequest request, @NonNull Chain chain) {

        return chain.next(request)
                .flatMap(response -> {
                    if (isSubscription(request)) {
                        return Mono.just(tapSubscriptionCompletion(response));
                    }
                    pollExecutionRecord();
                    return Mono.just(response);
                })
                .doOnError(_ -> pollExecutionRecord());
    }

    private WebGraphQlResponse tapSubscriptionCompletion(WebGraphQlResponse response) {
        Publisher<ExecutionResult> originalPublisher = response.getExecutionResult().getData();
        Flux<ExecutionResult> tapped = Flux.from(originalPublisher)
                .doFinally(_ -> pollExecutionRecord());
        return response.transform(builder -> builder.data(tapped));
    }

    private void pollExecutionRecord() {
        mockGraphQlServerObjectProvider.getObject().pollExecutionRecord();
    }

    private boolean isSubscription(WebGraphQlRequest request) {
        var document = request.getDocument();
        if (document == null || document.isBlank()) return false;
        try {
            var operationName = request.getOperationName();
            return new graphql.parser.Parser()
                    .parseDocument(document)
                    .getDefinitions().stream()
                    .filter(graphql.language.OperationDefinition.class::isInstance)
                    .map(graphql.language.OperationDefinition.class::cast)
                    .filter(op -> operationName == null
                            || operationName.isBlank()
                            || operationName.equals(op.getName()))
                    .findFirst()
                    .map(op -> op.getOperation()
                            == graphql.language.OperationDefinition.Operation.SUBSCRIPTION)
                    .orElse(false);
        } catch (Exception ignored) {
            return false;
        }
    }
}
