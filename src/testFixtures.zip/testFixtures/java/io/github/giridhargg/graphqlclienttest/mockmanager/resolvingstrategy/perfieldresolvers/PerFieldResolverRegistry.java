package io.github.giridhargg.graphqlclienttest.mockmanager.resolvingstrategy.perfieldresolvers;

import org.jspecify.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Holds per-(type,field) resolver registrations for a single ExecutionRecord.
 * Lookup is by exact (typeName, fieldName) match - applies to every instance
 * of that type encountered during execution, regardless of path/depth/list index.
 */
public final class PerFieldResolverRegistry {

    private final Map<FieldCoordinate, FieldResolver> resolvers = new LinkedHashMap<>();

    public PerFieldResolverRegistry register(String typeName, String fieldName, FieldResolver resolver) {
        resolvers.put(FieldCoordinate.of(typeName, fieldName), resolver);
        return this;
    }

    public PerFieldResolverRegistry register(FieldCoordinate coordinate, FieldResolver resolver) {
        resolvers.put(coordinate, resolver);
        return this;
    }

    @Nullable
    public FieldResolver lookup(String typeName, String fieldName) {
        return resolvers.get(FieldCoordinate.of(typeName, fieldName));
    }

    public boolean isEmpty() {
        return resolvers.isEmpty();
    }

    public Map<FieldCoordinate, FieldResolver> asMap() {
        return Map.copyOf(resolvers);
    }
}