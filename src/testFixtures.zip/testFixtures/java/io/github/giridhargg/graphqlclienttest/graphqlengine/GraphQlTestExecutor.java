package io.github.giridhargg.graphqlclienttest.graphqlengine;

import graphql.ExecutionInput;
import graphql.ExecutionResult;
import graphql.GraphQL;
import graphql.schema.DataFetcher;
import graphql.schema.FieldCoordinates;
import graphql.schema.GraphQLObjectType;
import io.github.giridhargg.graphqlclienttest.mockmanager.MockGraphQlServer;
import org.jspecify.annotations.Nullable;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.test.context.TestComponent;
import reactor.core.publisher.Flux;

import java.util.Map;

@TestComponent
public class GraphQlTestExecutor {

    private final GraphQL graphQL;

    private final GraphQlStaticTestAssets.Assets assets;

    public GraphQlTestExecutor(
            ObjectProvider<MockGraphQlServer> mockGraphQlServerProvider,
            GraphQlStaticTestAssets.Assets assets) {
        this.assets = assets;

        if (assets.compiledSchema() == null) {
            throw new IllegalStateException(
                    "GraphQlTestExecutor requires a GraphQl schema but none was found. "
                            + "Ensure a graphql schema file exists at the configured location "
                            + "{graphql.test.assets.schema-location}");
        }
        var baseSchema = assets.compiledSchema();

        // registers all types
        var newCodeRegistry = baseSchema.getCodeRegistry().transform(registry -> {
            for (var type : baseSchema.getAllTypesAsList()) {
                if (type instanceof GraphQLObjectType objectType
                        && !objectType.getName().startsWith("__")) {  // skip introspection types
                    for (var field : objectType.getFieldDefinitions()) {
                        registry.dataFetcher(
                                FieldCoordinates.coordinates(objectType.getName(), field.getName()),
                                (DataFetcher<?>) dfe -> {
                                    try {
                                        return mockGraphQlServerProvider.getObject().resolve(dfe);
                                    } catch (Throwable e) {
                                        throw new RuntimeException(e);
                                    }
                                });
                    }
                }
            }
        });

        this.graphQL = GraphQL
                .newGraphQL(baseSchema.transform(builder -> builder.codeRegistry(newCodeRegistry)))
                .build();
    }

    public Map<String, Object> executeQuery(String query, @Nullable Map<String, Object> variables) {
        return executeQuery(query, variables, null, null);
    }

    public Map<String, Object> executeQuery(String query, @Nullable Map<String, Object> variables, @Nullable String operationName) {
        return executeQuery(query, variables, operationName, null);
    }

    public Map<String, Object> executeQuery(
            String query,
            @Nullable Map<String, Object> variables,
            @Nullable String operationName,
            @Nullable Map<String, Object> extensions) {
        var builder = ExecutionInput.newExecutionInput().query(query);
        if (variables != null) builder.variables(variables);
        if (operationName != null) builder.operationName(operationName);
        if (extensions != null) builder.extensions(extensions);
        return executeInput(builder.build());
    }

    public Flux<Map<String, Object>> executeSubscription(String query, @Nullable Map<String, Object> variables) {
        return executeSubscription(query, variables, null, null);
    }

    public Flux<Map<String, Object>> executeSubscription(String query, @Nullable Map<String, Object> variables, @Nullable String operationName) {
        return executeSubscription(query, variables, operationName, null);
    }

    public Flux<Map<String, Object>> executeSubscription(
            String query,
            @Nullable Map<String, Object> variables,
            @Nullable String operationName,
            @Nullable Map<String, Object> extensions) {
        var builder = ExecutionInput.newExecutionInput().query(query);
        if (variables != null) builder.variables(variables);
        if (operationName != null) builder.operationName(operationName);
        if (extensions != null) builder.extensions(extensions);
        var executionResult = graphQL.execute(builder.build());
        Publisher<ExecutionResult> source = executionResult.getData();
        return Flux.from(source).map(ExecutionResult::toSpecification);
    }

    public Map<String, Object> executeInput(ExecutionInput executionInput) {
        return graphQL.execute(executionInput).toSpecification();
    }

    public GraphQlStaticTestAssets.Assets getGraphQlStaticAssets() {
        return assets;
    }
}
