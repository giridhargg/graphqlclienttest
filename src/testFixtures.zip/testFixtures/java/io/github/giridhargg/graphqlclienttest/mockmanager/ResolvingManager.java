package io.github.giridhargg.graphqlclienttest.mockmanager;

import graphql.ExecutionInput;
import graphql.GraphQLError;
import graphql.GraphqlErrorBuilder;
import graphql.execution.DataFetcherResult;
import graphql.execution.ResultPath;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.PropertyDataFetcher;
import io.github.giridhargg.graphqlclienttest.mockmanager.resolvingstrategy.perfieldresolvers.PerFieldResolverRegistry;
import io.github.giridhargg.graphqlclienttest.mockmanager.resolvingstrategy.typesafenestedbuilders.GraphNode;
import org.jspecify.annotations.Nullable;
import reactor.core.publisher.Flux;

import java.util.ArrayDeque;
import java.util.Objects;
import java.util.Queue;

import static org.assertj.core.api.Assertions.assertThat;

class ResolvingManager {

    protected final Queue<ExecutionRecord> inputs = new ArrayDeque<>();

    public ResolvingManager.ExecutionQueueBuilder expectInput(ExecutionInput executionInput) {
        return new ResolvingManager.ExecutionQueueBuilder(executionInput, ExecutionRecord.MatchType.PARTIAL);
    }

    public ResolvingManager.ExecutionQueueBuilder expectExactInput(ExecutionInput executionInput) {
        return new ResolvingManager.ExecutionQueueBuilder(executionInput, ExecutionRecord.MatchType.EXACT);
    }

    public void resolveFrom(GraphNode node) {
        this.inputs.add(ExecutionRecord.DeepPathBased.of(node));
    }

    public void resolveFrom(PerFieldResolverRegistry registry) {
        this.inputs.add(ExecutionRecord.PerFieldResolverBased.of(registry));
    }

    public void matchExecutionInput(ExecutionInput actualInput) {
        var executionRecord = inputs.peek();
        if (executionRecord == null) return;

        var expectedInput = executionRecord.executionInput();
        if (expectedInput == null) return;
        if (Objects.equals(executionRecord.matchType(), ExecutionRecord.MatchType.EXACT)) {
            matchExact(expectedInput, actualInput);
        } else {
            match(expectedInput, actualInput);
        }
    }

    private void match(ExecutionInput expectedInput, ExecutionInput actualInput) {
        // expected and actual object's target positions are switched here for lenient comparison
        // which is, actual object can contain any kind of fields and values, but it should contain
        // all the fields and values that are present in expected.
        assertThat(expectedInput)
                .usingRecursiveComparison()
                .ignoringExpectedNullFields()
                .isEqualTo(actualInput);
    }

    private void matchExact(ExecutionInput expectedInput, ExecutionInput actualInput) {
        assertThat(actualInput)
                .usingRecursiveComparison()
                .isEqualTo(expectedInput);
    }

    // =========================================================================================
    // DEEP_PATH_BASED resolution (new - Option A: typed GraphNode tree)
    // =========================================================================================

    private @Nullable Object resolveDeepPathBased(DataFetchingEnvironment environment, ExecutionRecord.DeepPathBased record) throws Throwable {

        var source = environment.getSource();
        Object localNode;

        if (source instanceof GraphNode parentNode) {
            // O(1) lookup - single field/index step from parent, no root re-walk
            var fieldName = environment.getField().getName();
            localNode = (parentNode instanceof GraphNode.ObjectNode obj) ? obj.get(fieldName) : null;
        } else {
            // First call (root field) - full navigation from the stubbed root map
            var allSegments = environment.getExecutionStepInfo().getPath().toList();
            if (allSegments.isEmpty()) return null;
            var rootFieldName = (String) allSegments.get(0);
            localNode = record.graphNode() instanceof GraphNode.ObjectNode objectNode ?
                objectNode.get(rootFieldName) : null; // now Object - compiles fine
        }

        if (localNode == null) {
            return PropertyDataFetcher.fetching(fieldKey(environment)).get(environment);
        }

        return switch (localNode) {
            case Flux<?> flux -> flux; // subscription root - graphql-java treats this as the event Publisher
            case GraphNode.LeafNode leaf -> resolveLeafValue(leaf.value(), environment);
            case GraphNode.ObjectNode obj -> obj;
            case GraphNode.ListNode list -> list.elements();
            default -> localNode; // plain scalar fallback, if ever stored directly
        };
    }

    // =========================================================================================
    // Shared helpers
    // =========================================================================================

    private @Nullable Object resolveLeafValue(@Nullable Object value, DataFetchingEnvironment environment) throws Throwable {
        if (value instanceof Throwable throwable) {
            throw throwable;
        }
        if (value instanceof GraphQLError graphQLError) {
            var enriched = enrichError(graphQLError, environment);
            return DataFetcherResult.newResult().error(enriched).data(null).build();
        }
        if (value instanceof DataFetcherResult<?> dataFetcherResult) {
            return dataFetcherResult;
        }
        return value;
    }

    private GraphQLError enrichError(GraphQLError original, DataFetchingEnvironment environment) {
        var builder = GraphqlErrorBuilder.newError(environment); // seeds path + location from environment!

        builder.message(original.getMessage());
        if (original.getErrorType() != null) {
            builder.errorType(original.getErrorType());
        }
        if (original.getExtensions() != null && !original.getExtensions().isEmpty()) {
            builder.extensions(original.getExtensions());
        }
        // If the original already explicitly set a path/location, prefer those:
        if (original.getPath() != null && !original.getPath().isEmpty()) {
            builder.path(ResultPath.fromList(original.getPath()));
        }
        if (original.getLocations() != null && !original.getLocations().isEmpty()) {
            builder.location(original.getLocations().getFirst());
        }

        return builder.build();
    }

    private String fieldKey(DataFetchingEnvironment environment) {
        var field = environment.getField();
        return field.getAlias() != null ? field.getAlias() : field.getName();
    }



    public @Nullable Object retrieveResponse(DataFetchingEnvironment environment) throws Throwable {
        var record = inputs.peek();
        if (record == null) return null;

        return switch (record) {
            case ExecutionRecord.DeepPathBased r -> resolveDeepPathBased(environment, r);
            case ExecutionRecord.PerFieldResolverBased r -> resolvePerFieldResolverBased(environment, r);
        };
    }

    // =========================================================================================
    // PER_FIELD_RESOLVER_BASED resolution (Option B)
    // =========================================================================================

    private @Nullable Object resolvePerFieldResolverBased(
            DataFetchingEnvironment environment, ExecutionRecord.PerFieldResolverBased record) throws Throwable {

        var typeName = parentTypeName(environment);
        var fieldName = environment.getField().getName(); // schema field name, NOT alias - resolver registration is type/field-based
        var registry = record.registry();

        var resolver = registry.lookup(typeName, fieldName);
        if (resolver == null) {
            // No resolver registered for this (type, field) - fall back to default property access
            // against whatever the parent resolver returned as "source"
            return PropertyDataFetcher.fetching(fieldKey(environment)).get(environment);
        }

        var result = resolver.resolve(environment);
        return resolveLeafValue(result, environment);
    }

    private String parentTypeName(DataFetchingEnvironment environment) {
        var parentType = environment.getParentType();
        if (parentType instanceof graphql.schema.GraphQLObjectType objType) {
            return objType.getName();
        }
        // Could be GraphQLInterfaceType etc. - use unwrapped type name as fallback
        return graphql.schema.GraphQLTypeUtil.simplePrint(parentType);
    }

    public void pollExecutionRecord() {
        inputs.poll();
    }

    public void reset() {
        inputs.clear();
    }

    public class ExecutionQueueBuilder {

        private final ExecutionRecord.MatchType matchType;

        private final ExecutionInput executionInput;

        public ExecutionQueueBuilder(
                ExecutionInput executionInput,
                ExecutionRecord.MatchType matchType) {
            this.matchType = matchType;
            this.executionInput = executionInput;
        }

        public void andResolveFrom(GraphNode graphNode) {
            inputs.add(new ExecutionRecord.DeepPathBased(executionInput, graphNode, matchType));
        }

        public void andResolveFrom(PerFieldResolverRegistry registry) {
            inputs.add(new ExecutionRecord.PerFieldResolverBased(executionInput, registry, matchType));
        }
    }
}
