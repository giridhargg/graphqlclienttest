package io.github.giridhargg.graphqlclienttest.httpgraphqlclient;

import io.github.giridhargg.graphqlclienttest.shared.MockGraphQlServerResetExtension;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.context.annotation.Import;
import org.springframework.core.annotation.AliasFor;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@ExtendWith({SpringExtension.class, MockGraphQlServerResetExtension.class})
@Import(HttpGraphQlClientTestAutoConfiguration.class)
@TestPropertySource
public @interface HttpGraphQlClientTest {

    /**
     * Additional classes that needs to be imported in the test scope where this annotation is used.
     */
    @AliasFor(annotation = Import.class, attribute = "value")
    Class<?>[] classes() default {};

    /**
     * Additional property source locations to load.
     * Merged with library defaults — consumer values take precedence.
     */
    @AliasFor(annotation = TestPropertySource.class, attribute = "locations")
    String[] propertySourceLocations() default {"classpath:graphql-client-test-defaults.properties"};

    /**
     * Additional configuration properties that are needed.
     * Inline property overrides file properties from above locations. Takes highest precedence.
     * Example: {"graphql.test.assets.schema-location=classpath:my-schema.graphqls"}
     */
    @AliasFor(annotation = TestPropertySource.class, attribute = "properties")
    String[] properties() default {};
}
