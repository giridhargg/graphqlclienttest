package io.github.giridhargg.graphqlclienttest.shared;

import io.github.giridhargg.graphqlclienttest.mockmanager.MockGraphQlServer;
import org.junit.jupiter.api.extension.BeforeEachCallback;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;

public class MockGraphQlServerResetExtension implements BeforeEachCallback {

    @Override
    public void beforeEach(ExtensionContext context) {
        var appContext = SpringExtension.getApplicationContext(context);
        appContext.getBeansOfType(MockGraphQlServer.class)
                .values()
                .forEach(MockGraphQlServer::reset);
    }
}