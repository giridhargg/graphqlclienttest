package io.github.giridhargg.graphqlclienttest.graphqlmvcconfig;

import graphql.schema.DataFetcher;
import graphql.schema.GraphQLObjectType;
import io.github.giridhargg.graphqlclienttest.graphqlengine.GraphQlStaticTestAssets;
import io.github.giridhargg.graphqlclienttest.graphqlengine.GraphQlStaticTestAssetsProperties;
import io.github.giridhargg.graphqlclienttest.mockmanager.MockGraphQlServer;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.graphql.execution.RuntimeWiringConfigurer;
import org.springframework.graphql.server.WebGraphQlInterceptor;

@TestConfiguration
@Profile("integrationTest")
@EnableConfigurationProperties(GraphQlStaticTestAssetsProperties.class)
public class RuntimeWiringTestAutoConfiguration {

    public static final String MOCK_GRAPHQL_RESOLVER = "mockGraphQlResolver";
    public static final String RUNTIME_WIRING_CONFIGURER = "runtimeWiringConfigurer";
    public static final String EXECUTION_POLLING_INTERCEPTOR = "executionRecordPollingInterceptor";
    public static final String GRAPHQL_STATIC_TEST_ASSETS = "graphQlStaticTestAssets";
    public static final String PERSISTED_QUERY_INTERCEPTOR = "persistedQueryInterceptor";

    @Primary
    @Bean(MOCK_GRAPHQL_RESOLVER)
    MockGraphQlServer mockGraphQlServer() {
        return MockGraphQlServer.createServer();
    }

    @Primary
    @Bean(EXECUTION_POLLING_INTERCEPTOR)
    ExecutionRecordPollingInterceptor executionRecordPollingInterceptor(ObjectProvider<MockGraphQlServer> mockGraphQlServerObjectProvider) {
        return new ExecutionRecordPollingInterceptor(mockGraphQlServerObjectProvider);
    }

    @Primary
    @Bean(GRAPHQL_STATIC_TEST_ASSETS)
    GraphQlStaticTestAssets.Assets assets(GraphQlStaticTestAssetsProperties properties) {
        return GraphQlStaticTestAssets.forPaths(properties);
    }

    @Primary
    @Bean(PERSISTED_QUERY_INTERCEPTOR)
    WebGraphQlInterceptor persistedQueryInterceptor(GraphQlStaticTestAssetsProperties properties) {
        return new PersistedQueryTestInterceptor(properties);
    }

    // register default-data-fetcher for every type of the graphql schema, depends to manually load and compile schema
    @Primary
    @Bean(RUNTIME_WIRING_CONFIGURER)
    @DependsOn({MOCK_GRAPHQL_RESOLVER, GRAPHQL_STATIC_TEST_ASSETS})
    RuntimeWiringConfigurer runtimeWiringTestConfigurer(
            @Qualifier(MOCK_GRAPHQL_RESOLVER)
            MockGraphQlServer mockGraphQlServer,
            @Qualifier(GRAPHQL_STATIC_TEST_ASSETS)
            GraphQlStaticTestAssets.Assets assets) {

        DataFetcher<?> unifiedFetcher = dfe -> {
            try {
                return mockGraphQlServer.resolve(dfe);
            } catch (Throwable e) {
                throw new RuntimeException(e);
            }
        };

        return wiringBuilder -> {
            for (var type : assets.compiledSchema().getAllTypesAsList()) {
                if (type instanceof GraphQLObjectType objectType
                        && !objectType.getName().startsWith("__")) {
                    wiringBuilder.type(objectType.getName(),
                            typeWiring -> typeWiring.defaultDataFetcher(unifiedFetcher));
                }
            }
        };
    }
}
