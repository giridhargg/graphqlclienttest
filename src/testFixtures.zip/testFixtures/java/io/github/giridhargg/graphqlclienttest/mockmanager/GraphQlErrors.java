package io.github.giridhargg.graphqlclienttest.mockmanager;

import graphql.ErrorClassification;
import graphql.ErrorType;
import graphql.GraphQLError;

import java.util.List;

public final class GraphQlErrors {

    public static GraphQLError validationError(String message, String... path) {
        return GraphQLError.newError()
                .errorType(ErrorType.ValidationError)
                .message(message)
                .path(List.of(path))
                .build();
    }

    public static GraphQLError executionAborted(String message) {
        return GraphQLError.newError()
                .errorType(ErrorType.ExecutionAborted)
                .message(message)
                .build();
    }

    public static GraphQLError dataFetchingError(String message, String... path) {
        return GraphQLError.newError()
                .errorType(ErrorType.DataFetchingException)
                .message(message)
                .path(List.of(path))
                .build();
    }

    public static GraphQLError custom(String message, ErrorClassification classification, String... path) {
        return GraphQLError.newError()
                .errorType(classification)
                .message(message)
                .path(List.of(path))
                .build();
    }
}
