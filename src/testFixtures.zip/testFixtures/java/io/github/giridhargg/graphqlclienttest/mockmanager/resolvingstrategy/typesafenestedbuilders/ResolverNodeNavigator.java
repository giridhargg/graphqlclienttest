package io.github.giridhargg.graphqlclienttest.mockmanager.resolvingstrategy.typesafenestedbuilders;

import graphql.execution.ResultPath;
import org.jspecify.annotations.Nullable;

import java.util.List;

public final class ResolverNodeNavigator {

    private ResolverNodeNavigator() {}

    /**
     * Navigate the tree following the given ResultPath, starting from rootField's child node.
     * The first path segment (the root field name, e.g. "bookById") is consumed by the caller
     * before invoking this - this navigates the REMAINING segments from that root node.
     *
     * Returns null if the path doesn't correspond to an explicitly-stubbed node, signalling
     * the caller to fall back to default property resolution.
     */
    // O(N * d) traversal
    @Nullable
    public static GraphNode navigate(GraphNode root, List<Object> remainingPathSegments) {
        var current = root;
        for (var segment : remainingPathSegments) {
            if (current == null) {
                return null;
            }
            current = switch (current) {
                case GraphNode.ObjectNode obj -> {
                    if (segment instanceof String fieldName && obj.has(fieldName)) {
                        yield obj.get(fieldName);
                    }
                    yield null; // field not explicitly stubbed
                }
                case GraphNode.ListNode list -> {
                    if (segment instanceof Integer index) {
                        yield list.get(index);
                    }
                    yield null; // shouldn't happen - list followed by non-integer segment
                }
                case GraphNode.LeafNode leaf -> null; // can't descend further into a leaf
            };
        }
        return current;
    }

    /**
     * Convert graphql-java's ResultPath to a list of segments (String for field names,
     * Integer for list indices), dropping the first N segments (typically 1, for the root field).
     */
    public static List<Object> pathSegmentsAfterRoot(ResultPath path) {
        var all = path.toList(); // e.g. ["bookById", "author", "bio"] or ["bookById", "reviews", 0, "rating"]
        return all.isEmpty() ? List.of() : all.subList(1, all.size());
    }
}