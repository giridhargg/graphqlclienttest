package io.github.giridhargg.graphqlclienttest.mockmanager;

import graphql.ExecutionInput;
import graphql.schema.DataFetchingEnvironment;
import io.github.giridhargg.graphqlclienttest.mockmanager.resolvingstrategy.perfieldresolvers.PerFieldResolverRegistry;
import io.github.giridhargg.graphqlclienttest.mockmanager.resolvingstrategy.typesafenestedbuilders.GraphNode;
import org.jspecify.annotations.Nullable;

public class MockGraphQlServer {

    private final ResolvingManager resolvingManager;

    public MockGraphQlServer() {
        this.resolvingManager = new ResolvingManager();
    }

    public static MockGraphQlServer createServer() {
        return new MockGraphQlServer();
    }

    public void pollExecutionRecord() {
        this.resolvingManager.pollExecutionRecord();
    }

    public void matchExecutionInput(ExecutionInput executionInput) {
        this.resolvingManager.matchExecutionInput(executionInput);
    }

    public ResolvingManager.ExecutionQueueBuilder expect(ExecutionInput executionInput) {
        return this.resolvingManager.expectInput(executionInput);
    }

    public ResolvingManager.ExecutionQueueBuilder expectExact(ExecutionInput executionInput) {
        return this.resolvingManager.expectExactInput(executionInput);
    }

    public void resolveFrom(GraphNode graphNode) {
        this.resolvingManager.resolveFrom(graphNode);
    }

    public void resolveFrom(PerFieldResolverRegistry registry) {
        this.resolvingManager.resolveFrom(registry);
    }

    public @Nullable Object resolve(DataFetchingEnvironment environment) throws Throwable {
        return retrieveResponse(environment);
    }

    public @Nullable Object retrieveResponse(DataFetchingEnvironment environment) throws Throwable {
        return this.resolvingManager.retrieveResponse(environment);
    }

    public void reset() {
        this.resolvingManager.reset();
    }
}
