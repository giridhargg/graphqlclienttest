package io.github.giridhargg.graphqlclienttest.mockmanager.resolvingstrategy.perfieldresolvers;

/**
 * Fluent builder for PER_FIELD_RESOLVER_BASED responses.
 *
 * Usage:
 *   PerFieldResolvers.builder()
 *       .query("bookById", env -> bookFixture)
 *       .type("Book").field("author", env -> authorFixture)
 *       .type("Author").field("bio", env -> SpringGraphQlErrors.notFound("Bio unavailable"))
 *       .register(graphQlServer);
 */
public final class PerFieldResolvers {

    private final PerFieldResolverRegistry registry = new PerFieldResolverRegistry();

    private PerFieldResolvers() {}

    public static PerFieldResolvers builder() {
        return new PerFieldResolvers();
    }

    // --- Root operation type shortcuts ---

    public PerFieldResolvers query(String fieldName, FieldResolver resolver) {
        registry.register("Query", fieldName, resolver);
        return this;
    }

    public PerFieldResolvers mutation(String fieldName, FieldResolver resolver) {
        registry.register("Mutation", fieldName, resolver);
        return this;
    }

    public PerFieldResolvers subscription(String fieldName, FieldResolver resolver) {
        registry.register("Subscription", fieldName, resolver);
        return this;
    }

    // --- Generic type/field registration ---

    public TypeScope type(String typeName) {
        return new TypeScope(typeName);
    }

    public PerFieldResolvers field(String typeName, String fieldName, FieldResolver resolver) {
        registry.register(typeName, fieldName, resolver);
        return this;
    }

    public PerFieldResolverRegistry build() {
        return registry;
    }

    public final class TypeScope {
        private final String typeName;

        private TypeScope(String typeName) {
            this.typeName = typeName;
        }

        public TypeScope field(String fieldName, FieldResolver resolver) {
            registry.register(typeName, fieldName, resolver);
            return this;
        }

        /** Return to the outer builder to switch to a different type or root operation. */
        public PerFieldResolvers and() {
            return PerFieldResolvers.this;
        }

        /** Convenience - terminal build without needing .and() first. */
        public PerFieldResolverRegistry build() {
            return PerFieldResolvers.this.build();
        }
    }
}