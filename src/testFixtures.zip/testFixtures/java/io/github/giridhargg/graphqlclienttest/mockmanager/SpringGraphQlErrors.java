package io.github.giridhargg.graphqlclienttest.mockmanager;

import graphql.ErrorClassification;
import graphql.GraphQLError;

import java.util.List;

public final class SpringGraphQlErrors {

    public static GraphQLError notFound(String message, String... path) {
        return error(org.springframework.graphql.execution.ErrorType.NOT_FOUND, message, path);
    }

    public static GraphQLError unauthorized(String message, String... path) {
        return error(org.springframework.graphql.execution.ErrorType.UNAUTHORIZED, message, path);
    }

    public static GraphQLError forbidden(String message, String... path) {
        return error(org.springframework.graphql.execution.ErrorType.FORBIDDEN, message, path);
    }

    public static GraphQLError badRequest(String message, String... path) {
        return error(org.springframework.graphql.execution.ErrorType.BAD_REQUEST, message, path);
    }

    public static GraphQLError internal(String message, String... path) {
        return error(org.springframework.graphql.execution.ErrorType.INTERNAL_ERROR, message, path);
    }

    private static GraphQLError error(ErrorClassification type, String message, String... path) {
        var builder = GraphQLError.newError().errorType(type).message(message);
        if (path.length > 0) builder.path(List.of(path));
        return builder.build();
    }
}
